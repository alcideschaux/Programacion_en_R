# Put initialization code in this file.
x <- 10
y <- rnorm(100)
data(cars)
z <- sample(c(rep(NA, 100), y), 20)
data(mtcars)
